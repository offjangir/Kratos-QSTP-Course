# QSTP-Kratos_electronics
Course material for QSTP '21 (Kratos-Electronics)

## Resources to learn 
* Arduino : [Jeremy Blum tutorials](https://www.youtube.com/playlist?list=PLA567CE235D39FA84)
* ROS : [ROSwiki tutorials](http://wiki.ros.org/ROS/Tutorials), [The ContructSim tutorials](https://www.youtube.com/watch?v=DBFYZRMLr70&list=PLK0b4e05LnzZWg_7QrIQWyvSPX2WN2ncc), [ROS in 5 days - Cheatsheet](https://docs.google.com/document/d/1qyxLRca5o0URCggOBt0i32CU8aDuOKr9LcjkfZ7vRE0/edit)
